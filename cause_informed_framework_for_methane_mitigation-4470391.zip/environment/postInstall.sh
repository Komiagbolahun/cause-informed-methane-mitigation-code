#!/bin/bash
pip install -r /environment/requirements.txt
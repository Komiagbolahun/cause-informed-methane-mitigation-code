#!/usr/bin/env bash
set -ex

# This is the master script for the capsule. When you click "Reproducible Run", the code in this file will execute.
jupyter nbconvert \
	--to 'html' \
	--ExecutePreprocessor.allow_errors=True \
	--ExecutePreprocessor.timeout=-1 \
	--FilesWriter.build_directory=../results \
	--execute 'Sharable Workbook for_Adekomi_et_al-Why Do Methane Emissions Occur Towards.ipynb'

# The previous version of this file was commented-out and follows below:
#
# #!/bin/bash
# # Ensure postInstall.sh is executable and run it to install dependencies
# chmod +x /environment/postInstall.sh
# /environment/postInstall.sh
# 
# # Execute the renamed Jupyter notebook headlessly
# jupyter nbconvert --execute --to notebook --inplace /code/Sharable\ Workbook\ for_Adekomi_et_al-Why\ Do\ Methane\ Emissions\ Occur\ Towards.ipynb

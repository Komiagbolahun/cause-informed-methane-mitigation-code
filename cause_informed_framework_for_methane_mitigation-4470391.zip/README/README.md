# Analysis Code for: "Cause-informed framework for risk-targeted methane emission mitigation in oil and gas operations"

**Capsule DOI:** https://doi.org/10.24433/CO.7756173.v1  
**Authors:** Muiz Adekomi et al.  
**Journal:** Nature Communications (under review / forthcoming)  
**Associated Preprint:** [https://chemrxiv.org/engage/chemrxiv/article-details/6892b728fc5f0acb52eca296]

This **Code Ocean Compute Capsule** contains all code, anonymized data, and computational environment needed to reproduce the statistical analyses, figures, and results in the main manuscript and Supplementary Information (SI). It processes aerial methane measurement data to categorize emission sources, quantify risks (FMEA/FTA), and assess temporal/operator-specific trends.

## Data Provenance and Anonymization
The primary input file (`1. Anonymized Causal Analysis S.xlsx`) is a compiled, processed version of raw operator reports.

- **Anonymization** — To comply with data-sharing agreements and protect confidentiality, sensitive fields (Facility Names, Facility IDs, Company Names mapped to A/B/C/etc., GPS coordinates) have been removed or pseudonymized.
- **Preprocessing** — Raw logs were aggregated beforehand. Equipment types were standardized using non-anonymized master facility lists (not included here) for consistency.
- **Scope** — Covers 1,669 investigated emission events (>10 kg/h) from the 2024 Appalachian Methane Initiative (AMI) campaign.

## Capsule Structure
- `Sharable_Workbook_Adekomi_et_al_Methane_Emissions.ipynb` (or your current main notebook name): Main Jupyter Notebook with all data cleaning, statistical tests (Monte Carlo, Chi-Square), and figure generation.
- `data/` — Input Excel file(s).
- `results/` — Where output figures, tables, and HTML exports are saved.
- `requirements.txt` — Exact Python dependencies (pinned versions for reproducibility).
- `README.md` — This file.

## Key Analysis Sections & Figure Mapping
The notebook runs sequentially. Sections map to manuscript/SI outputs as follows:

| Notebook Section                  | Output Item              | Description                                                                 |
|-----------------------------------|--------------------------|-----------------------------------------------------------------------------|
| Blocks 1–2: Data Checking/Cleaning| N/A                      | Harmonizes raw operator descriptions into 11 causal categories.             |
| Block 3                           | Supplementary Fig. 1     | Operator-reported events across unharmonized causes (sorted).               |
| Blocks 4–5                        | N/A                      | Event and rate distributions across harmonized categories.                  |
| Uncertainty Analysis              | N/A                      | Monte Carlo (n=1000) for 95% CIs on frequency/rate (seed=42 for reproducibility). |
| Block 6                           | Supplementary Fig. 2     | Harmonized event distribution with uncertainty bounds.                      |
| Block 7                           | Supplementary Fig. 3     | Harmonized emissions rate distribution with uncertainty bounds.             |
| Block 8                           | Supplementary Fig. 4     | Actionable causal category event distribution.                              |
| Block 9                           | Supplementary Fig. 5     | Actionable causal category emissions rate distribution.                     |
| Block 10                          | Figure 1                 | Basin-wide causal category analysis.                                        |
| Block 11                          | Figure 2                 | Cumulative frequency and super-emitter counts.                              |
| Block 12                          | Figure 3                 | Escalation Ratio (Small vs. Large Emitters).                                |
| Block 13                          | Figure 4                 | FMEA Risk Priority Number (RPN) composite.                                  |
| Block 14                          | Figure 6                 | Inter-operator variation (Chi-Square tests).                                |
| Block 15                          | Figure 5                 | Temporal variation (Chi-Square tests).                                      |
| Block 16                          | Supplementary Fig. 8     | Event duration distributions (box/strip plots).                             |

## System Requirements & Environment
- **Python version:** 3.12 (pre-configured in capsule base image)
- **Key packages:** pandas==2.3.2, numpy==2.3.2, matplotlib==3.10.6, seaborn==0.13.2, scipy==1.16.1, openpyxl==3.1.5, jupyter==1.1.1 (see `requirements.txt` for full list)

## How to Reproduce
**Easiest way (recommended for reviewers/readers):**
1. Open this capsule on Code Ocean.
2. Click **Reproducible Run** (top-right button) — this automatically executes the full pipeline in the verified environment.
3. Outputs appear in `/results` (figures as PNG/PDF, tables, HTML report if configured).

**Manual execution:**
1. Open the main notebook (`Sharable_Workbook_Adekomi_et_al_Methane_Emissions.ipynb`).
2. Ensure the input file path is correct (usually `./data/1. Anonymized Causal Analysis S.xlsx`).
3. Run all cells sequentially.
4. **Reproducibility note:** Set `RANDOM_SEED = 42` in the Uncertainty Analysis block ensures consistent Monte Carlo results.

Questions or issues? Contact the corresponding author or use Code Ocean's comment feature.

